
CREATE TABLE Location (
    locationID INT AUTO_INCREMENT PRIMARY KEY,
    city VARCHAR(50) DEFAULT 'Karachi',
    country VARCHAR(50) DEFAULT 'Pakistan'
);
CREATE TABLE Department (
    deptID INT AUTO_INCREMENT PRIMARY KEY,
    deptName VARCHAR(50) NOT NULL,
    locationID INT,
    FOREIGN KEY (locationID) REFERENCES Location(locationID)
);
CREATE TABLE Job (
    jobID VARCHAR(10) PRIMARY KEY,
    jobTitle VARCHAR(50) NOT NULL,
    salary DECIMAL(10, 2)
);
CREATE TABLE Employee (
    employeeID INT AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    hiringDate DATE,
    deptID INT,
    jobID VARCHAR(10),
    FOREIGN KEY (deptID) REFERENCES Department(deptID),
    FOREIGN KEY (jobID) REFERENCES Job(jobID)
);
INSERT INTO Location (city, country)
VALUES
    ('Karachi', 'Pakistan'),
    ('Lahore', 'Pakistan'),
    ('Islamabad', 'Pakistan'),
    ('Dubai', 'UAE');
INSERT INTO Department (deptName, locationID)
VALUES
    ('Engineering', 1),
    ('HR', 2),
    ('Finance', 3),
    ('IT', 4);
INSERT INTO Job (jobID, jobTitle, salary)
VALUES
    ('ENG123', 'Engineer', 50000),
    ('MAN456', 'Manager', 75000),
    ('HR789', 'HR Specialist', 45000),
    ('FIN012', 'Financial Analyst', 60000);
INSERT INTO Employee (firstName, lastName, hiringDate, deptID, jobID)
VALUES
    ('Ali', 'Khan', '2020-05-01', 1, 'ENG123'),
    ('Sara', 'Ahmed', '2019-03-15', 2, 'MAN456'),
    ('Bilal', 'Iqbal', '2021-01-10', 3, 'FIN012'),
    ('Fatima', 'Noor', '2022-07-22', 4, 'HR789');
SELECT * FROM Location;
SELECT * FROM Department;
SELECT * FROM Job;
SELECT * FROM Employee;
