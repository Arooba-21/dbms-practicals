USE studentdb;
SELECT D.deptName,AVG(MIN(J.salary)) AS avg_min_salary
FROM Department D
JOIN Employee E ON E.deptID = D.deptID
JOIN Job J ON E.jobID = J.jobID
GROUP BY D.deptName;

SELECT D.deptName,(SUM(J.salary*100) / (SELECT SUM(salary) FROM Job)) AS salary_percentage
FROM Department D
JOIN Employee E ON E.deptID = D.deptID
JOIN Job J ON E.jobID = J.jobID
GROUP BY D.deptName;

CREATE TABLE high_salary (
    firstName VARCHAR(50),
    lastName VARCHAR(50),
    jobTitle VARCHAR(50),
    salary DECIMAL(10, 2),
    deptName VARCHAR(50)
);
INSERT INTO high_salary (firstName, lastName, jobTitle, salary, deptName)
SELECT E.firstName, E.lastName, J.jobTitle, J.salary, D.deptName
FROM Employee E
JOIN Job J ON E.jobID = J.jobID
JOIN Department D ON E.deptID = D.deptID
WHERE J.salary > 60000;

