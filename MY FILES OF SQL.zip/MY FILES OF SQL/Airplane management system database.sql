create database huat; 
show databases;
use huat;
create table flight_information (airline varchar (250), dep_date date, arr_date date, arrival varchar (255), destination varchar (255), price int(20),time_of_dep time, time_of_arr time, total_time int (10), class varchar (25));
insert into flight_information Values ('Airblue', '2025-2-8', '2025-2-8', 'Karachi Jinnah International Airport', 'Islamabad International Airport', 20000, '12:30:00', '04:30:00', 2, 'Business'),
('PIA ', '2025-2-8', '2025-2-8', 'Karachi Jinnah International Airport', 'Islamabad International Airport', 19000, '01:30:00', '03:30:00', 2, 'Economy'),
('Fly Jinnah ', '2025-2-8', '2025-2-8', 'Karachi Jinnah International Airport', 'Islamabad International Airport', 24000, '11:30:00', '01:30:00', 2, 'Premium Economy');
select*from flight_information;

 -- create table flight_information (airline varchar (250), dep_date date, arr_date date, arrival varchar (255), destination varchar (255), price int(20),time_of_dep time, time_of_arr time, total_time int (10), class varchar (25));
insert into flight_information Values ('Emirates', '2025-3-6', '2025-3-6', 'Karachi Jinnah International Airport', 'Dubai International Airport ', 150000, '12:30:00', '02:30:00', 2, 'Business'),
('PIA ', '2025-3-6', '2025-3-6', 'Karachi Jinnah International Airport', 'Dubai International Airport ', 190000, '01:30:00', '04:00:00', 2, 'Economy'),
('Fly Jinnah ', '2025-3-6', '2025-3-6', 'Karachi Jinnah International Airport', 'Dubai International Airport ', 240000, '6:30:00', '08:30:00', 2, 'Premium Economy');
select*from flight_information;

insert into flight_information Values ('Emirates', '2025-3-7', '2025-3-7', 'Saudi Arab International Airport', 'Dubai International Airport ', 120000, '04:30:00', '5:30:00', 1, 'Business'),
('PIA ', '2025-3-7', '2025-3-7', 'Saudi Arab International Airport', 'Dubai International Airport ', 19000, '10:30:00', '11:30:00', 1, 'Business'),
('Fly Jinnah ', '2025-3-7', '2025-3-7', 'Saudi Arab International Airport', 'Dubai International Airport ', 34000, '6:30:00', '08:30:00', 1, 'Premium Economy');
select*from flight_information;

insert into flight_information Values ('Emirates', '2025-3-7', '2025-3-7', 'Malaysia International Airport', 'Kuwait International Airport ', 560000, '10:30:00', '3:30:00', 5, 'Economy'),
('PIA ', '2025-3-7', '2025-3-7', 'Malaysia International Airport', 'Kuwait International Airport ', 98000, '06:30:00', '11:30:00', 5, 'Business'),
('Fly Jinnah ', '2025-3-7', '2025-3-7', 'Malaysia International Airport', 'Kuwait International Airport ', 74000, '08:30:00', '12:30:00', 5, 'Economy');
select*from flight_information;

insert into flight_information Values ('Turkish Airline', '2025-3-5', '2025-3-5', 'Turkey International Airport', 'Russia International Airport ', 78000, '10:30:00', '4:30:00', 6, 'Economy'),
('AirSial ', '2025-3-5', '2025-3-5', 'Turkey International Airport', 'Russia International Airport ', 10800, '06:30:00', '12:30:00', 6, 'Economy'),
('Salam Air', '2025-3-5', '2025-3-6', 'Turkey International Airport', 'Russia International Airport ', 87000, '08:30:00', '01:30:00', 6, 'Economy');

CREATE TABLE Traveler (
    FirstName VARCHAR(255) NOT NULL,
    LastName VARCHAR(255) NOT NULL,
    DateOfBirth DATE NOT NULL,
    CNIC VARCHAR(255) NOT NULL
);
CREATE TABLE ContactDetails (
    MobileNumber VARCHAR(255) NOT NULL,
    Email VARCHAR(255) NOT NULL
);
CREATE TABLE CardDetails (
    NameOnCard VARCHAR(255) NOT NULL,
    CardNumber VARCHAR(255) NOT NULL,
    Expiry DATE NOT NULL,
    CVV VARCHAR(10) NOT NULL
);
describe flight_information;