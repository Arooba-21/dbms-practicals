SELECT e.firstName, e.lastName, j.jobTitle, j.salary
FROM Employee e
JOIN Job j ON e.jobID = j.jobID
WHERE j.salary = (SELECT MAX(salary) FROM Job);

SELECT e.firstName, e.lastName, 
       TIMESTAMPDIFF(YEAR, e.hiringDate, CURDATE()) AS experience
FROM Employee e
WHERE e.hiringDate = (SELECT MIN(hiringDate) FROM Employee);

SELECT e.firstName, e.lastName, j.salary
FROM Employee e
JOIN Job j ON e.jobID = j.jobID
WHERE j.salary > (SELECT AVG(salary) FROM Job);

SELECT e.firstName, e.lastName, d.deptName
FROM Employee e
JOIN Department d ON e.deptID = d.deptID
JOIN Job j ON e.jobID = j.jobID
WHERE j.salary = (
    SELECT MAX(j1.salary)
    FROM Employee e1
    JOIN Job j1 ON e1.jobID = j1.jobID
    WHERE e1.deptID = e.deptID
);
