CREATE TABLE employee
(id int(3) PRIMARY KEY, first_name varchar(15), last_name varchar(15), designation varchar(50), department varchar (20), auditors varchar (15), cities varchar(15), salary float (10,2),experience int (3));
DESCRIBE employee; 
INSERT INTO employee (id, first_name, last_name, designation, department, auditors, cities, salary, experience)
VALUES 
(1, 'Aisha', 'Iqbal', 'Lecturer', 'BSCS', 'Salman', 'Karachi', 5600.34, 8),
(2, 'Sahiba', 'Shezad', 'Lecturer', 'AI', 'Aqib', 'Islamabad', 30000, 2),
(3, 'Aqib', 'Ikhlas', 'Teacher', 'BSCS', 'Manal', 'Lahore', 89000, 10),
(4, 'Shezad', 'Aslam', 'Lecturer', 'CY', 'Shahid', 'Karachi', 40000, 7);
ALTER TABLE employee DROP first_name, DROP last_name; 
DESCRIBE employee; 
ALTER TABLE employee ADD employee_name varchar (20) AFTER id; 
DESCRIBE employee; 
SELECT CONCAT(employee_name, ', ', designation, ', ', department) AS Employee_Details
FROM employee;
SELECT COUNT(auditors) AS Total_Auditors FROM employee; 
SELECT cities, department, COUNT(*) AS Number_of_Employees
FROM employee
GROUP BY cities, department;
SELECT AVG(salary) FROM employee
GROUP BY department; 
SELECT department, COUNT(*) AS Number_of_Employees_Over_8_Years
FROM employee
WHERE experience > 8
GROUP BY department;
SELECT designation, SUM(salary) FROM employee
GROUP BY designation
ORDER BY designation DESC; 
SELECT COUNT(*) FROM employee;
SELECT cities, 
department, 
ROUND(AVG(salary), 2) AS Average_Salary
FROM employee
GROUP BY cities, department
HAVING AVG(salary) >= 70000;
