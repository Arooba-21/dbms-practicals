CREATE DATABASE studentDB;
SHOW DATABASES;
USE studentDB;
CREATE TABLE students (
    stud_id INT(3),
    stud_name VARCHAR(50),
    stud_phone INT(7),
    stud_gpa INT(1)
);
SHOW TABLES;
DESCRIBE students;
RENAME TABLE students TO student;
SHOW TABLES;
ALTER TABLE student
    CHANGE COLUMN stud_id id INT(3),
    CHANGE COLUMN stud_name name VARCHAR(50),
    CHANGE COLUMN stud_phone phone INT(10),
    CHANGE COLUMN stud_gpa gpa FLOAT(3,2);
DESCRIBE student;
INSERT INTO student (id, name, phone, gpa)
VALUES
    (1, 'Ali Khan', 3001234567, 3.50),
    (2, 'Sara Ahmed', 3002345678, 3.80),
    (3, 'Bilal Iqbal', 3003456789, 3.60),
    (4, 'Nida Shah', 3004567890, 3.90);
SELECT * FROM student;
DELETE FROM student WHERE id = 3;
SELECT * FROM student;
INSERT INTO student (id, name) 
VALUES
    (5, 'Ayesha Malik'),
    (6, 'Hamza Ali');
SELECT * FROM student;
UPDATE student
SET phone = 3005678901, gpa = 3.75
WHERE id = 5;
UPDATE student
SET phone = 3006789012, gpa = 3.85
WHERE id = 6;
SELECT * FROM student;
DELETE FROM student WHERE id = 1;
DELETE FROM student WHERE id = 2;
SELECT * FROM student;
INSERT INTO student (id, name, phone, gpa)
VALUES
    (7, 'Usman Raza', 3007890123, 3.95),
    (8, 'Mehreen Zahid', 3008901234, 3.65),
    (9, 'Omar Tariq', 3009012345, 3.70),
    (10, 'Fatima Noor', 3009123456, 3.80);
SELECT * FROM student;
TRUNCATE TABLE student;
SELECT * FROM student;
SELECT * FROM student LIMIT 1 OFFSET 1;
