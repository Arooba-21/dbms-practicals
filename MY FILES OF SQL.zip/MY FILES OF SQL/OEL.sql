use studentdb;
-- Display the average minimum salaries of all departments.
SELECT deptName, AVG(min_salary) AS avgsalary
FROM (SELECT D.deptName,
        MIN(J.salary) AS min_salary
    FROM Employee E
    JOIN Department D ON E.deptID = D.deptID
    JOIN Job J ON E.jobID = J.jobID
    GROUP BY 
        D.deptID  
) AS dept_min_salaries
GROUP BY deptName;  

-- Display the percentage of salary expenses for each department.
SELECT D.deptName, 
    (SUM(salary*100) / (SELECT SUM(salary) FROM Job))AS salary_percentage
FROM Employee E
JOIN Department D ON E.deptID = D.deptID
JOIN Job J ON E.jobID = J.jobID
GROUP BY D.deptName;

-- Insert into a new table, high-salary, the names, designations, salaries, and departments of all the employees with a salary greater than 60000.
CREATE TABLE high_salary (
    firstName VARCHAR(50),
    lastName VARCHAR(50),
    jobTitle VARCHAR(50),
    salary DECIMAL(10, 2),
    deptName VARCHAR(50)
);
INSERT INTO high_salary (firstName, lastName, jobTitle, salary, deptName)
SELECT E.firstName,E.lastName,J.jobTitle,J.salary,E.deptID
FROM Employee E
JOIN Job J ON E.jobID = J.jobID
WHERE J.salary > 60000;

-- TASK 02
-- Print an employee Last name (first letter capital) and job title (Lower Case).
SELECT 
    CONCAT(UPPER(SUBSTRING(lastName, 1, 1)), LOWER(SUBSTRING(lastName, 2)))AS NAME,
    LOWER(jobTitle) AS Jobtitle
FROM Employee E
JOIN Job J ON E.jobID = J.jobID;
    
-- List all the Employees having an‘aa’in their last_name.
SELECT firstName, lastName
FROM Employee
WHERE lastName LIKE '%aa%';

-- Write a query to display the number of employees with the same Job_Title.
SELECT jobTitle, COUNT(*) AS num_employees
FROM Employee E
JOIN Job J ON E.jobID = J.jobID
GROUP BY jobTitle;

-- Display employee first name and job joined together, length of employee_name, for all employees who are in sales.
SELECT CONCAT(firstName, ' ', jobTitle) AS employee_name,
    LENGTH(CONCAT(firstName, ' ', LastName)) AS employee_name_length
FROM Employee E
JOIN Job J ON E.jobID = J.jobID
WHERE J.jobTitle = 'Sales';

-- Write a query in SQL to display the first name of all employees including the first name of their manager using only the employee table.
SELECT E.firstName AS employee_first_name,
      M.firstName AS manager_first_name
FROM Employee E
LEFT JOIN Employee M ON E.managerID = M.employeeID;

-- Write a query Update salary of employees by 50% increment having maximum salary of 7000.
UPDATE Job
SET salary = salary * 1.5
WHERE salary <= 7000;

-- Write a query in SQL to display the name of the department, average salary, and number of employees working in that department who got a commission
ALTER table Employee ADD column commission int;
describe Employee;
Insert into Employee(commission) values(10),(20),(22),(33);
SELECT D.deptName,
    AVG(J.salary) AS avg_salary,
    COUNT(E.employeeID) AS num_employees_with_commission
FROM Employee E
JOIN Department D ON E.deptID = D.deptID
JOIN Job j ON E.jobID = j.jobID
WHERE E.commission IS NOT NULL  
GROUP BY D.deptName;

-- Display First_Name, and Hire_date of all the employees who were hired before 20-May-2017. Keeping this in mind that hire dates should be displayed in the format “DD-MM-YY”. Also date in the where clause should be in the format “DD-MM-YY”.
SELECT firstName,
    DATE_FORMAT(hiringDate, '%d-%m-%y') AS hire_date
FROM Employee
WHERE hiringDate < STR_TO_DATE('20-05-17', '%d-%m-%y');

-- Write a query to display the first name, salary, email, and department ID for all those employees who earn more than the average salary and arrange the list in descending order of salary.
ALTER table Employee ADD column email varchar(50);
Insert into Employee(email) values("ABCDEFGH"),("hhhijaijia");
SELECT firstName, salary, email, deptID
FROM Employee e
JOIN Job j ON e.jobID=j.jobID
WHERE j.salary > (SELECT AVG(salary) FROM Job)
ORDER BY salary DESC;

