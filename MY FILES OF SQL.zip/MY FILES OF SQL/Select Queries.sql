use studentdb;
ALTER TABLE student
    ADD COLUMN DOB DATE,
    ADD COLUMN Semester INT,
    ADD COLUMN Department VARCHAR(50),
    ADD COLUMN GPA FLOAT(3,2);
INSERT INTO student (id, name, DOB, semester, department, GPA) 
VALUES
    (1, 'Ali Khan', '2000-04-01', 4, 'Computer Science', 3.75),
    (2, 'Sara Ahmed', '1999-11-23', 3, 'Mechanical Engineering', 3.45),
    (3, 'Bilal Iqbal', '2001-06-15', 2, 'Electrical Engineering', 2.90),
    (4, 'Fatima Noor', '2000-02-09', 5, 'Civil Engineering', 3.50),
    (5, 'Usman Raza', '2001-05-01', 1, 'Computer Science', 3.80),
    (6, 'Mehreen Zahid', '1998-09-14', 6, 'Chemical Engineering', 3.60),
    (7, 'Hamza Ali', '1999-07-10', 4, 'Computer Science', 2.65),
    (8, 'Nida Shah', '2000-12-30', 3, 'Software Engineering', 3.20),
    (9, 'Omar Tariq', '2001-08-25', 2, 'Business Administration', 3.45),
    (10, 'Zainab Jamil', '2001-10-03', 1, 'Architecture', 3.90);
SELECT * FROM student;

SELECT id, name, department FROM student;

SELECT DISTINCT department FROM student;

SELECT name AS "Student Name", department AS "Department", DOB AS "Date of Birth" FROM student;

SELECT * FROM student WHERE department = 'Computer Science';

SELECT name, department FROM student ORDER BY name;

SELECT name, department, GPA FROM student ORDER BY GPA DESC;

SELECT name, department, GPA FROM student ORDER BY GPA DESC LIMIT 3;

SELECT name, GPA FROM student ORDER BY GPA DESC LIMIT 3, 3;

SELECT name, GPA FROM student ORDER BY GPA ASC LIMIT 3;

SELECT name, semester, GPA FROM student WHERE department = 'Computer Science';

SELECT name, semester, department FROM student WHERE department != 'Computer Science';

SELECT name, semester, GPA, department FROM student WHERE GPA < 2.5 AND semester >= 5;

SELECT name, semester FROM student WHERE department = 'Computer Science' OR GPA > 3.5;

SELECT name, DOB, department FROM student WHERE DOB > '2000-01-01' OR semester < 3;

SELECT name, GPA FROM student WHERE GPA BETWEEN 2.5 AND 3.5;

SELECT name FROM student WHERE name LIKE '%a%';
