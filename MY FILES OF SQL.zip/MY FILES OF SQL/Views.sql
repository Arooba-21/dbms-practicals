use studentdb;
describe student;
-- Create a view StudentView having three columns: student’s full name, department name, and GPA. Show the structure of the view.
CREATE VIEW StudentView AS 
SELECT name,department,gpa
FROM student;
describe StudentView;

-- Display a list of all the students having GPA greater than 3.0.
SELECT * FROM StudentView
WHERE gpa > 3.0;

-- Insert a new record in the student table. Also, ensure that the student has a GPA.
INSERT INTO student(name, department, gpa)
VALUES ('Arooba Jawaid','BSCS', 3.5); 

-- Display all the records in Student, and StudentView.
SELECT * FROM student;
SELECT * FROM StudentView;
