use studentdb;
CREATE TABLE students (
    name VARCHAR(50),
    last_name VARCHAR(50)
);
CREATE INDEX idx_last_name
ON students (last_name);

CREATE TABLE departments(
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(100) NOT NULL
);
CREATE UNIQUE INDEX unique_department_name
ON departments (department_name);

