use studentdb;

SELECT d.deptName, COUNT(e.employeeID) AS number_of_employees
FROM Department d
LEFT JOIN Employee e ON d.deptID = e.deptID
GROUP BY d.deptName;

SELECT d.deptName, MAX(j.salary) AS max_salary
FROM Department d
JOIN Employee e ON d.deptID = e.deptID
JOIN Job j ON e.jobID = j.jobID
GROUP BY d.deptName;

SELECT e.employeeID, CONCAT(e.firstName, ' ', e.lastName) AS full_name, j.jobTitle, j.salary
FROM Employee e
JOIN Job j ON e.jobID = j.jobID
WHERE j.salary = (SELECT MIN(salary) FROM Job);

SELECT l.country, COUNT(d.deptID) AS total_departments
FROM Department d
JOIN Location l ON d.locationID = l.locationID
GROUP BY l.country
HAVING COUNT(d.deptID) > 2;

SELECT DISTINCT l.city
FROM Location l
JOIN Department d ON l.locationID = d.locationID
UNION
SELECT DISTINCT l.city
FROM Employee e
JOIN Department d ON e.deptID = d.deptID
JOIN Location l ON d.locationID = l.locationID;

SELECT d.deptName, CONCAT(e.firstName, ' ', e.lastName) AS employee_name
FROM Department d
LEFT JOIN Employee e ON d.deptID = e.deptID;
