-- A retail company wants to analyze the sales table to understand trends. However, it doesn’t want to modify
-- the original table during analysis. To achieve this, it uses cloning to create a copy of the sales table and
-- temporary tables for intermediate results.
show databases;
use studentdb;
show tables;
create table sales (
    product_id int not null,    
    product_name varchar(50) not null,
    customer_id int not null,                 
    customer_name varchar(50) not null,
    salesperson_id INT,                       
    total_sale_amount DECIMAL(10, 2) NOT NULL, 
    order_status VARCHAR(20) NOT NULL      
);

INSERT INTO sales (product_id, product_name, customer_id, customer_name, salesperson_id, total_sale_amount, order_status) VALUES
(1, 'Laptop', 1006, 'Arooba', 506, 1200.00, 'Completed'),
(2, 'Smartphone', 1007, 'Urooj', 507, 800.00, 'Completed'),
(3, 'Headphones', 1008, 'Ali', 508, 150.00, 'Pending'),
(4, 'Smartwatch', 1009, 'Amna', 509, 300.00, 'Completed'),
(5, 'Tablet', 1010, 'Hiba', 510, 600.00, 'Cancelled');

CREATE TABLE sales_clone AS
SELECT * FROM sales;

CREATE TEMPORARY TABLE temp_sales AS
SELECT * FROM sales_clone
WHERE order_status = 'Completed';

select product_name as product_sale
 from temp_sales;
 
SELECT SUM(total_sale_amount) AS total_sales
FROM temp_sales;

SELECT COUNT(*) AS completed_sales_count
FROM temp_sales;
DROP TABLE IF EXISTS temp_sales;  

-- A company wants to analyze employee performance data. They frequently calculate each employees total
-- sales and average rating but dont want to repeatedly write complex queries. They use a VIEW for this
-- purpose. During a session, they perform additional analysis using a temporary table.

CREATE TABLE employee_performance (
    employee_id INT NOT NULL,
    employee_name VARCHAR(50) NOT NULL,
    total_sales DECIMAL(10, 2) NOT NULL,
    rating DECIMAL(3, 2) NOT NULL,  
    PRIMARY KEY (employee_id)
);
INSERT INTO employee_performance (employee_id, employee_name, total_sales, rating) VALUES
(1, 'Arooba', 15000.00, 4.5),
(2, 'Urooj', 20000.00, 4.8),
(3, 'D', 12000.00, 3.9),
(4, 'Amna', 18000.00, 4.2),
(5, 'Hiba', 22000.00, 4.9),
(6, 'Sara ', 16000.00, 4.1);

CREATE VIEW employee_performance_summary AS
SELECT 
    employee_id,
    employee_name,
    SUM(total_sales) AS total_sales,
    AVG(rating) AS average_rating
FROM 
    employee_performance
GROUP BY 
    employee_id, employee_name;

SELECT * FROM employee_performance_summary;

CREATE TEMPORARY TABLE high_performers AS
SELECT * FROM employee_performance_summary
WHERE average_rating > 4.0;

SELECT COUNT(*) AS high_performers_count
FROM high_performers;

SELECT SUM(total_sales) AS total_sales_high_performers
FROM high_performers;

-- Step 6: Clean up (optional)
DROP TABLE IF EXISTS high_performers;  -- Optional, as it will be dropped automatically

