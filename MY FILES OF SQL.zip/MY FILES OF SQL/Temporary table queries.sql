CREATE TEMPORARY TABLE EmployeeInfo AS
SELECT CONCAT(E.firstName, ' ', E.lastName) AS fullName,
    J.jobTitle,
    D.deptName AS department
FROM Employee E
JOIN Job J ON E.jobID = J.jobID
JOIN Department D ON E.deptID = D.deptID;

DESCRIBE EmployeeInfo;

CREATE TABLE EmployeeClone LIKE Employee;

DESCRIBE Employee;
DESCRIBE EmployeeClone;

SELECT * FROM EmployeeClone;
DROP TEMPORARY TABLE EmployeeInfo;


